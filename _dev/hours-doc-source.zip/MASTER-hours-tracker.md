# hours.therapistsupport.org — master design document

**Version 2.0 · 12 August 2026**
**This is the entry point. Read this first; everything else is detail.**

---

## 0. How to keep this updated

**The rule: this document is the index and the state. Everything else is an
appendix to it.**

1. **Update §2 (decisions) or §3 (open questions)** — those two sections *are*
   the state of the project.
2. **Add a line to §7 (changelog)** with the date and what changed.
3. **If a detail doc is superseded, mark it in §6** rather than deleting it.
4. **If something turns out to be wrong, add it to §5 (known-wrong)** — do not
   quietly fix it. The corrections list is the most valuable page here.
5. **Amend detail docs by appending a dated `## Amendment` block**, never by
   rewriting them.
6. **Rebuild and re-deliver the rendered design document before the session ends.**
   Any session that changes a decision, adds a prototype, or logs a correction must
   re-run `hours-doc/build.py` and send the user the updated file. The master doc is
   the state; the rendered document is a *render* of it. If they drift, this document
   wins and the render is stale. See `design-doc-render-protocol`.

A future session should be able to read this document alone and be current.

---

## 1. What this is

A BBS supervised-hours tracker for California associates, **trainees and
students**, at `hours.therapistsupport.org`, feeding from the 130-page content
site at `therapistsupport.org`.

**The one-sentence positioning:**

> The licensure record that also watches the calendar — so the week you forgot,
> the deadline you didn't know about, and the supervisor who left don't cost you
> your registration.

**The four claims:** it watches dates · there's a name on it · every rule is
cited · **it fills itself in, and you still sign it.**

**The call to action, everywhere:** *Connect your calendar and see where you
actually are* — never "start tracking".

**The three buyers, named:** the **organised newcomer** (the minority) · the
**lapsed logger** — 12–24 months in, stopped, avoiding it, whom every competitor
fails · and the **student**, whom nobody reaches at all.

**The trainee thesis:** *the most expensive mistakes in California licensure are
made before you graduate, and every existing tool starts after.*

---

## 2. Decisions locked

| Decision | Choice | Where argued |
|---|---|---|
| **Stack** | Rails 8, Hotwire, SQLite + Solid Queue, Propshaft, import maps | stack-and-costs |
| **Hosting** | Hetzner + Kamal 2, ~$34–43/mo | stack-and-costs |
| **PDF generation** | `hexapdf` filling the Board's own AcroForms | rules-verification |
| **Tracks** | All three — AMFT, ASW, APCC | market-and-model |
| **Rules architecture** | Versioned, effective-dated YAML with citations | rules-verification |
| **Pricing** | Free trainee/student → **$99/yr or $12/mo** | strategy-case |
| **Billing** | **No auto-renewal, ever** | auth-payments-entity |
| **Free tier gate** | BBS registration number, self-declared | strategy-case |
| **Supervisor signing** | Signed link + emailed code, **no account** | economics-hipaa-esignature |
| **HIPAA** | Out of scope — **no client identifiers, ever** | economics-hipaa-esignature |
| **Entity** | CA LLC, formed in January if possible | auth-payments-entity |
| **Auth** | Magic links, no passwords | auth-payments-entity |
| **Email** | Resend. **Not** Klaviyo | market-and-model |
| **Support** | Own-domain KB + Help Scout free tier. **Live human help is a paid feature** | market-and-model, trainee-tier |
| **Community forum** | **No.** Decided and closed | forum-decided-against |
| **AI assistant** | **No.** Human-written cited help instead | feature-ideas |
| **"AI-powered" as language** | **Never used anywhere** | seo-plan amendment |
| **Insurance sales** | **No.** Track the policy, don't sell it | *(11 Aug)* |
| **Client-facing booking** | **No.** Takes identity, reason and money | scheduling-decision |
| **Calendar-derived logging** | **Yes — Phase 2.** Browser-side parse, assist mode, **never auto-commit** | calendar-derived-logging |
| **Multi-calendar, labelled** | **Yes.** Tagged to a setting at connect. Personal: busy only | availability-sharing |
| **Availability sharing** | **Yes — Phase 2, included in $99.** Display-only free/busy | availability-sharing |
| **Supervision scheduling** | **Yes — Phase 2/3**, via the availability link | availability-sharing |
| **Backfill** | **Yes — Phase 2, the acquisition hook.** Month-at-a-time, **no bulk confirm** | backfill-and-patent-marking |
| **Historic rule application** | **Each week judged by the ruleset in force that week** | backfill-and-patent-marking |
| **Calendar posture** | **Read-only, one-way.** No EHR APIs, no write scope. **The browser-parsed `.ics` path must always remain available** | calendar-derived-logging |
| **Patent** | **Provisional on the narrow claim, filed BEFORE publishing the mechanism** | calendar-derived-logging |
| **"Patent pending" marking** | Only once filed, on the capture feature only. **Never in-app** | backfill-and-patent-marking |
| **Trainee tier scope** | **A different product, not a lite version.** Ships the graduation-transition engine first | **trainee-tier** |
| **Track honesty** | **State "zero countable hours" plainly for APCC and MSW students.** Never imply practicum hours bank when they don't | **trainee-tier** |
| **School dashboard** | **NEVER build one.** A roster or SSO converts a syllabus link into a 1–6 month procurement under FERPA's school-official exception. **The student shares; we never contract with an institution** | **trainee-tier** |
| **VPAT + HECVAT Lite** | **Publish both voluntarily, before anyone asks.** Removes the main reason a programme director escalates to IT | **trainee-tier** |
| **Accessibility** | **Build to WCAG 2.1 AA from the start.** ADA Title II compliance dates 26 Apr 2027 / 2028 for public institutions, and it reaches vendor-provided content | **trainee-tier** |
| **Game design** | **Yes — ratchets, never towers.** Requirement cards, binding-gate line, the what-if toy, designed moments, restrained juice. Sound off by default | game-design-lenses |
| **Gamification** | **No.** Streaks, leaderboards, points, badges, avatars, loss-aversion prompts and login rewards each fail one of Schell's own lenses | game-design-lenses |
| **Product vocabulary** | **Adopt it.** This Week · The Clock · Countersign · Catch Up · Proof · The Gates · What If · The Bottleneck · The Vault · Sunday. Free, memorable, and nobody in the category has named anything | thirtysignals-direction |
| **Visual direction — SETTLED** | **Direction B is the chassis** (app, marketing, everything touched weekly); **Direction A is the evidence layer** (wherever a rule is cited). Paper-and-mono only ever means "the Board's words, not ours" | final-proposal-and-the-mark |
| **The mark** | **Stroke H** — same stroke weight and round caps as the ring — as primary; **monogram tile** as the companion icon below ~40px | final-proposal-and-the-mark |

---

## 3. Open questions

1. **Free trainee → paid conversion rate.** No benchmark exists. Instrument from user one.
2. **Support tickets per user per month.** The binding constraint at scale.
3. **Typed-name-only e-signature acceptable to the Board?** Unverified.
4. **Trainee population size.** Derived, not counted. ~7,000–10,000.
5. **Real keyword volumes.** Pull from Search Console.
6. ~~Will supervisors publish availability?~~ **Resolved — they don't have to.**
   ~~**Reopened 12 Aug: which visual direction?**~~ **Closed 12 Aug — Direction B is
   the chassis, Direction A is the evidence layer, split by emotional state rather
   than by page.** What remains worth testing with associates is the copy and the
   vocabulary, not the palette.
7. ⚠️ **How many associates keep a usable calendar?** **Largest risk in the plan.**
   Ten conversations, **before any calendar code.**
8. **Does a patent attorney think the narrow claim is filable?** Blocks publication.
9. **Employer objections to publishing free/busy from a practice calendar?**
10. **Real time saved per week?** ~40 min → ~90 sec is a hypothesis. Publish the truth.
11. **Scheduled vs actual time in the calendar?** Overstatement risk.
12. **Is the SimplePractice dependency acceptable?** They own TrackYourHours.
    Mitigation is architectural — the `.ics` path is vendor-independent.
13. ⚠️ **Is the 500-practicum-hour exemption from the six-year rule real?** One
    verification pass read §4980.43(c)(7) as exempting up to 500 clinical practicum
    hours; another could not confirm it and found the Handbook contradicting.
    **High consequence — resolve by hand against the statute before encoding.**
14. **Does the 90-day window run from the conferral date or the transcript-posting
    date** when they differ? Statute says one, BBS Form 37A-647 says the other.
    Also: calendar or business days? Also: is a timely-but-deficient application
    preserved once cured? **No guidance found on any of the three.**
15. **Statutory citations for the LPCC 6-hour suicide-risk and 3-hour telehealth
    requirements.** Confirmed from BBS forms only.
16. ⚠️ **The market denominator may be ~15% too high.** BBS's own FY 2023–24
    sunset review reports **AMFT 15,042 · ASW 16,517 · APCC 5,112 = 36,671**
    associates. Our model used ~43,000. At 36,671, **5,000 paying is 13.6% of the
    market, not 11.6%.** Reconcile the definitions before quoting the model again.
17. **Did Tevera's "lifetime access" survive the Lumivero rebrand?** Institutional
    pages still say yes; Lumivero's own page doesn't mention it.

---

## 4. Current build order

**Phase 0 — before code.** ✅ Rules verification. **Provisional patent decision,
before any publication of the mechanism.** **Ten calendar conversations (§3.7).**
**Resolve §3.13 by hand.** Then publish the rulesets.
**Phase 1.** AMFT free tier · deadline engine · **ICS deadline feed** · contextual
help · founder page · honest comparison page.
**Phase 1b — the trainee MLP.** **Graduation-transition engine** (Live Scan alert,
90-day clock, pre/post-degree log split — all three tracks) · practicum-gap
detector · supervisor + site qualification check · 60-day Supervision Agreement
deadline · pre-degree log with honest per-track framing.
**Phase 2 — the calendar phase, all one integration.** Connect + label by setting ·
backfill · calendar-derived logging · completeness + drift · availability sharing ·
supervisor slot-pick → draft unit · ASW + APCC · supervisor signed-link flow ·
Stripe · school outreach.
**Phase 3.** Verification of Experience generation · carry-forward moment ·
supervisor dashboard · practice plan · transcript audit · career/pay layer ·
disciplinary case library as an ethics resource.
**Phase 4.** CEU tracking · benchmarks · processing-times tracker ·
**the State of California Licensure report.**

---

## 5. Known-wrong — do not repeat these

**Corrections 1–6, from the 11 Aug verification pass. All mine.**

| Wrong | Right |
|---|---|
| "90-day supervision agreement window" | **60 days** — and it is a regulation, **16 CCR §1833(c)**, not a statute. |
| L&E must be *passed* before first renewal | Must be **taken**, not passed. |
| You can sit the clinical exam before 3,000 hours | **You cannot**, on any track. |
| Six-year clock runs from registration | Rolling lookback from Board **receipt of the application**. |
| 250-hour workshop cap | **No such cap.** |
| Personal psychotherapy is creditable | **It is not a category at all.** |

Also: SparkHours is **not** an anonymous shell.

**7 — "EHR integration is partner-gated, therefore no calendar integration."**
Wrong conclusion from a true premise; the EHRs already sync into Google/Apple/M365.

**8 — collapsing "availability sharing" into "booking."** A free/busy link takes
no name, no email, no reason and no payment.

**9 — treating the buyer as the organised newcomer.** The funnel had no segment
for the lapsed logger.

**10 — the pre-degree caps were cited to the wrong section.** We had
§4980.43.2; they are **§4980.43(c)(4) and (c)(5)**. §4980.43.2 governs
supervision frequency and format.

**11 — we recorded "1,300 (750 sub-cap)" without knowing what the 750 covered.**
It is **counseling AND direct supervisor contact, combined**. So **at least 550 of
the 1,300 must be non-clinical.** (And the lifetime non-clinical ceiling of 1,250
sits below 1,300, so non-clinical can't fill it either.)

**12 — we materially understated the 90-day rule.** It is four conjunctive
conditions, identical across all three tracks (§4980.43(b) · §4999.46(b) ·
§4996.23(b)), and **one of them must be satisfied before the degree** — see the
trainee doc.

**Two traps, both baited, neither yet sprung:** applying today's rules to
backfilled historic weeks (wrong-but-plausible, no error); and auto-committing
hours from a calendar (demos better, destroys the attestation).

**Verified rule base additions, 11 Aug:**
- **BPC §4980.43.3** — associates/trainees are employees or volunteers only,
  never contractors (a); may not be paid by clients (e); may not own the
  employer's business (f); **trainees may not be in private practice at all** (b).
  An associate on a **subsequent registration** cannot work in private practice.
- **The 90-day rule + Live Scan**: post-degree pre-registration hours count only
  if the Board *receives* the application within 90 days of degree granting; the
  workplace *required completed Live Scan before the hours were gained* (2020+
  grads); and the Board subsequently grants registration. **Hours count only from
  the date on the processed Live Scan form, prints are not transferable between
  employers, and trainees are not otherwise required to be fingerprinted.**
- **§4980.42(c)** — a practicum-enrolment lapse of **90 days or more voids every
  hour gained in it**.
- **§4980.42(e)** — the school must approve each site and hold a **written
  agreement** with it.
- **§4980.03(g)** — supervisor eligibility is **two parallel two-year tests**:
  licensed ≥2 of the last 5 (g)(1), *and* practised or supervised ≥2 of the last
  5 (g)(2).
- **Pre- and post-degree hours must be on separate Weekly Logs and separate
  Experience Verification forms** (BBS FAQ Q49).
- **APCC has a statutory trainee status** (§4999.12(g)) that confers **zero** hour
  credit. **LCSW has no trainee status at all.**
- **APCC/MSW pre-degree hours count zero** toward the 3,000 (§4999.46(c)(1),
  §4996.23(a)). The LPCC degree separately requires **280 f2f supervised
  counselling hours** (§4999.33(c)(3)(L)), certified by the school on Form
  **37A-667**. CSWE requires **900 MSW field hours**, which the BBS never inspects.
- **AB 462 removed** the LPCC couples/families 6-units+500-hours requirement and
  the 150 hours in a hospital/community mental health setting, eff. 1 Jan 2022.
- **35 U.S.C. §292** — false "patent pending" is an offence when done to deceive;
  $500/offence to the US, **but an injured competitor may sue under §292(b)**. A
  provisional permits the notice for 12 months and then dies by operation of law.

---

## 6. Document index

| Doc | What it holds | Status |
|---|---|---|
| **MASTER** *(this)* | Index, decisions, changelog | **Current** |
| `bbs-rules-verification-and-corrections` | The six corrections + verified rules | **Current — read second.** Amend: pre-degree cap citation (§5.10–11) |
| `calendar-derived-logging-and-patent-posture` | Capture design, PHI boundary, patent | **Current — read third** |
| `calendar-backfill-and-patent-marking` | Connect flow, backfill, §292 marking | **Current — read fourth** |
| `trainee-tier-design-and-university-channel` | Trainee product, FERPA architecture, accreditation pitch | **Current — read fifth** |
| `design-doc-render-protocol` | The rendered design doc: build system, logo decisions, rebuild rule | **Current** |
| `game-design-lenses-applied` | Schell's lenses applied; the eight to build and seven refused | **Current** |
| `thirtysignals-direction-and-vocabulary` | Second visual direction; the product vocabulary; what not to borrow | **Current** |
| `final-proposal-and-the-mark` | **The recommendation**: chassis/evidence split, both journeys end to end, the logo | **Current — read fifth** |
| `value-expansion-parked-ideas` | Renewal market, bus factor, public calculator — proposals, not decisions | **Current** |
| `availability-sharing-included` | Free/busy link, supervisor loop, price frame | Current |
| `hours-tracker-strategy-case` | Porter, path to #1, pricing | Current — amended 11 Aug |
| `hours-tracker-blue-ocean-strategy` | Four Actions, Six Paths, value stack | Current — amended 11 Aug |
| `hours-tracker-moats-and-differentiation` | Moats by copy-difficulty | Current — amended 11 Aug |
| `hours-tracker-seo-and-conversion-plan` | Content tiers, conversion units | Current — amended 11 Aug |
| `hours-tracker-market-size-and-model` | DCA population, P&L | **Amend — denominator disputed (§3.16)** |
| `hours-tracker-economics-hipaa-esignature` | Costs, HIPAA, e-signature | Current **except §4** |
| `hours-tracker-auth-payments-entity` | Logins, Stripe, CA LLC, ARL | Current |
| `hours-tracker-stack-and-costs` | Stack, hosting comparison | Current |
| `hours-tracker-emotional-design` | The emotional layer | Current |
| `scheduling-decision-no-client-booking` | Why booking is out | Current — calendar/availability positions superseded |
| `hours-tracker-feature-ideas` | Feature backlog | **Amend** — "sit exam early" is dead |
| `fb-demand-index-2026-08-11` · `fb-research-corpus-schema` | Demand corpus + schema | Current |
| `community-forum-decided-against` | Forum decision | Current |

**Artifacts not in the project** (keep in `_dev/`): `amft.yml` · `asw.yml` ·
`apcc.yml` · `fb-research.jsonl` · twelve HTML mockups (newest: `trainee-tier.html`,
`calendar-connect.html`, `availability-link.html`, `calendar-assist.html`,
`scheduling-screens.html`) · `command-center.html`.

⚠️ **The command centre is stale** — built at v1.0, predates every calendar and
trainee decision. Rebuild from `build_cc.py` before relying on it.

---

## 7. Changelog

**v2.0 — 12 Aug 2026. THE FINAL PROPOSAL.** **Visual direction settled** — Direction B
as the chassis, Direction A as the evidence layer, split by *emotional state* rather
than by page: the app is read weekly by a tired person and should feel light; the law
is read at the moment someone asks "says who?" and must look checkable. Paper-and-mono
now means one thing only — the Board's words. **Both user journeys built end to end**:
Sam (free practicum student, six steps across two years, converting at registration
because two years of his data is already in the account) and Dana (AMFT, seven steps,
arriving ashamed and recovering 68 weeks in eleven seconds). Confirmed as a locked
principle that **the trainee tier is a separate product, not a gated one** — Sam's
product is about dates and traps, Dana's about recovery and proof. **Appointment
importing documented in full**, including the hashed reference that enables reschedule
detection with no client record. **Nine differentiators tabled** with why each resists
copying. **Ten logo variations** with the capital H drawn in SVG rather than typed;
stroke-H recommended as primary, monogram tile as the companion icon. Design document
rebuilt to v2.0 with 17 prototypes and written to `therapy-practice-site/hours/index.html`
— **awaiting the user's commit and push**.

**v1.9 — 12 Aug 2026.** **A second visual direction built — the product as 37signals
would make it.** The real output is not the pixels but **a vocabulary**: This Week,
The Clock, Countersign, Catch Up, Proof, The Gates, What If, The Bottleneck, The
Vault, Sunday — adopted regardless of which visual direction wins, because every
competitor uses the same grey nouns and the names are therefore free. Also recorded:
which parts of the 37signals house style would actively hurt this audience (jokes
near consequences; "you don't need that feature"; contrarianism as a brand). The two
visual directions are deliberately left undecided, to be settled by five associates
rather than by taste. Separately, a **parked-ideas** doc was added covering the
biennial-renewal market (89,276 licensed CA clinicians vs 36,671 associates), the
bus-factor continuity plan, and a free public "am I okay?" calculator. Rendered
design document rebuilt to v1.9 with 15 prototypes and written to
`therapy-practice-site/hours/index.html` — **awaiting the user's commit and push**.

**v1.8 — 12 Aug 2026.** **Jesse Schell's lenses applied to the question of making
the product more fun.** The framework rejects gamification using its own tests —
the Lens of Punishment kills streaks before the clinical argument starts, and the
Lens of Endogenous Value says the currency is already real, so the job is making
enormous true value visible rather than inventing points. **Eight mechanics
adopted** (juice on confirm, requirement cards with the statute on the back, the
binding-gate line, milestones announced early, the what-if simulator as a toy, the
52nd-week moment, the journey replay, "permanently met" language); **seven refused
with named reasons**. First genuinely interactive prototype: `gameplay-screens.html`.
Rendered design document rebuilt to v1.8 with 14 prototypes and written to
`therapy-practice-site/hours/index.html` — **awaiting the user's commit and push**.

**v1.7 — 11 Aug 2026.** **The rendered design document shipped** — a single
password-protected HTML file for `therapistsupport.org/hours/`, with all 13 prototypes
embedded and running live, plus brand identity, logo concepts, marketing copy and the
open-decisions board. Confirmed the content site is **GitHub Pages, not Netlify**, so
it is a drop-in file rather than a deploy. **Rule 6 added to §0:** every future session
rebuilds and re-delivers it. Logo direction chosen — *the date ring*, which doubles as
the **o** in the wordmark. Name held at "hours" for parent-domain SEO.

**v1.6 — 11 Aug 2026.** **The trainee/student tier designed as a separate
product.** Three verification passes produced **three corrections to our own
record** (§5.10–12): the pre-degree caps were mis-cited, the 750 sub-cap meaning
was unknown, and the 90-day rule was materially understated. Identified the
**Live Scan pre-graduation trap** — post-degree hours count only from the date on
a workplace Live Scan form that must pre-date them, which means the action has to
happen while the person is still a trainee. **Only a product that engages students
pre-degree can surface it.** Track-honest design locked (zero countable hours for
APCC and MSW, said plainly). **FERPA architecture locked: never build a school
dashboard** — a roster or SSO converts a syllabus link into a 1–6 month
procurement; the student shares instead. VPAT + HECVAT Lite to be published
voluntarily; WCAG 2.1 AA from the start. Accreditation pitch established
(COAMFTE 70% licensure benchmark; BBS school-by-school pass rates for the 95 of
106 CA programmes that aren't COAMFTE-accredited). Phase 1b added. Five open
questions added, two of them flagged high-consequence (§3.13, §3.16).

**v1.5 — 11 Aug 2026.** Sync pass — the four flagged docs amended, index clean.
Lapsed logger named; switching-cost inversion; SimplePractice dependency;
**entry effort** added to the strategy canvas; **capture demoted to a
non-moat**, archived historic rulesets identified as the real one; CTA changed
site-wide; five lapsed-logger panic pages.

**v1.4 — 11 Aug 2026.** Backfill adopted as the acquisition hook. No bulk confirm;
backfilled weeks marked permanently. Historic weeks judged by historic rules.
"Patent pending" marking approved with five §292 rules and a placement map.

**v1.3 — 11 Aug 2026.** Availability sharing adopted, included in $99. Eighth
correction. Supervision scheduling moved earlier via the slot-pick loop.

**v1.2 — 11 Aug 2026.** Calendar-derived logging adopted. Seventh correction.
Patent decision reversed.

**v1.1 — 11 Aug 2026.** Client-facing booking declined on statutory grounds.
ICS deadline feed pulled into Phase 1.

**v1.0 — 11 Aug 2026.** Document created. Competitive sweep, demand corpus, rules
verification, strategy case, blue ocean analysis, seven mockups, six corrections.

---

## 8. What to do next

**Four things. The first three are cheap and they gate everything expensive.** (And per §0 rule 6, rebuild the rendered design document whenever any of this changes.)

1. **Decide the provisional patent question before publishing anything that
   describes the capture mechanism.** Publication destroys novelty.
2. **Resolve §3.13 by hand** — the 500-practicum-hour six-year exemption. Two
   verification passes disagreed and it is high-consequence.
3. **Ask ten real associates whether their calendar is any good** (§3.7). All of
   Phase 2 rests on it.
4. **Then publish the comparison page and the founder page**, and take the
   one-page accreditation pitch to three programme directors. Not to students —
   **to the number they are publicly accountable for and currently cannot move.**
