# hours — design document build system

## What this is
`dist/hours/index.html` is a single self-contained, password-protected file.
Drop it in your GitHub Pages repo as `/hours/index.html` and it publishes at
https://therapistsupport.org/hours/

- All 13 prototypes are embedded and run live inside it. No external assets except web fonts.
- The body is AES-256-GCM encrypted; the key is PBKDF2-SHA256 over your passphrase, 600,000 iterations.
- `<meta name="robots" content="noindex,nofollow,noarchive">` is set.

## Rebuild
    python3 build.py "your passphrase here"

Default passphrase if you omit it: countersign-week-71

## To change content
- `part1.html` — cover, product, problem, market, competition, moats, features
- `part2.html` — screens, brand, marketing, plan, decisions, known-wrong, protocol
- `data.json`  — decisions / decisions-to-make / corrections / changelog (rendered by JS)
- `MOCKUPS` in `build.py` — the list of prototype files to embed, in display order

Add a prototype: drop `foo.html` next to the other prototypes, add `"foo"` to MOCKUPS,
add a `<figure class="scr" data-k="foo">` block to part2.html, rebuild.

## Security, honestly
The ciphertext is public. Encryption is real, but the only thing protecting it is
passphrase strength — use something long. This is right for a private working
document, not for secrets.
