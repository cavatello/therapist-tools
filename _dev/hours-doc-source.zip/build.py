#!/usr/bin/env python3
"""
Build the hours design document.

  python3 build.py [passphrase]

Reads part1.html, part2.html, data.json and the prototype HTML files,
bundles them, gzips, encrypts with AES-256-GCM (PBKDF2-SHA256, 600k iters),
and writes dist/hours/index.html — a single self-contained file that works
on GitHub Pages, Netlify, S3, or straight off disk.

To update: edit the parts / data.json, add prototypes to MOCKUPS, re-run.
"""
import json, gzip, base64, os, sys, secrets, hashlib

HERE = os.path.dirname(os.path.abspath(__file__))
SRC  = os.path.dirname(HERE)          # prototypes live one level up
PASS = sys.argv[1] if len(sys.argv) > 1 else "countersign-week-71"
ITER = 600_000

MOCKUPS = [
    "trainee-tier", "calendar-connect", "calendar-assist", "availability-link",
    "scheduling-screens", "marketing-site", "app-screens-v2", "moat-screens",
    "human-screens", "signature-flow", "contextual-help", "hours-style",
    "strategy-canvas",
]

def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()

# ---- assemble the bundle -----------------------------------------------
html = read(f"{HERE}/part1.html") + "\n" + read(f"{HERE}/part2.html")
data = json.load(open(f"{HERE}/data.json", encoding="utf-8"))

mockups = {}
missing = []
for k in MOCKUPS:
    p = f"{SRC}/{k}.html"
    if os.path.exists(p):
        mockups[k] = read(p)
    else:
        missing.append(k)

bundle = json.dumps({"html": html, "data": data, "mockups": mockups},
                    ensure_ascii=False).encode("utf-8")
packed = gzip.compress(bundle, 9)

# ---- encrypt -----------------------------------------------------------
try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
except ImportError:
    sys.exit("pip install cryptography --break-system-packages")

salt = secrets.token_bytes(16)
iv   = secrets.token_bytes(12)
key  = hashlib.pbkdf2_hmac("sha256", PASS.encode(), salt, ITER, 32)
ct   = AESGCM(key).encrypt(iv, packed, None)

# ---- write -------------------------------------------------------------
out = (read(f"{HERE}/shell.html")
       .replace("__PAYLOAD__", base64.b64encode(ct).decode())
       .replace("__SALT__",    base64.b64encode(salt).decode())
       .replace("__IV__",      base64.b64encode(iv).decode())
       .replace("__ITER__",    str(ITER)))

os.makedirs(f"{HERE}/dist/hours", exist_ok=True)
dest = f"{HERE}/dist/hours/index.html"
with open(dest, "w", encoding="utf-8") as f:
    f.write(out)

print(f"prototypes embedded : {len(mockups)}/{len(MOCKUPS)}")
if missing:
    print(f"  MISSING           : {', '.join(missing)}")
print(f"bundle (raw)        : {len(bundle)/1024:.0f} KB")
print(f"bundle (gzipped)    : {len(packed)/1024:.0f} KB")
print(f"output              : {os.path.getsize(dest)/1024:.0f} KB  ->  {dest}")
print(f"passphrase          : {PASS}")
